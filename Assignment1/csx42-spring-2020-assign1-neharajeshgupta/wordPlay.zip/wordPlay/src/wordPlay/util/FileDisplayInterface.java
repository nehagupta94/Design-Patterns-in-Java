package wordPlay.util;

public interface FileDisplayInterface {
	
}
