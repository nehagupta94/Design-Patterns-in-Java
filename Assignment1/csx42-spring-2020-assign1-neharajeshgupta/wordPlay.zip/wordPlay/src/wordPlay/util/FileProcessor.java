package wordPlay.util;

import java.io.IOException;

public class FileProcessor {
	String[] args = {"input.txt","output.txt","metrics.txt"};

	public void readFile(String[] args) throws IOException {

    }
}
