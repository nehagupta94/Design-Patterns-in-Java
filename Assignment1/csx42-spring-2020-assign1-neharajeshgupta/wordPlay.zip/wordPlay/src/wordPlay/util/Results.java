package wordPlay.util;

public class Results implements FileDisplayInterface, StdoutDisplayInterface {
	
}
