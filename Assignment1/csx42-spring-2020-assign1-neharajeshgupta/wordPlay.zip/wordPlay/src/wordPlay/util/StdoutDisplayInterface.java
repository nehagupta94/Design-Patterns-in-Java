package wordPlay.util;

public interface StdoutDisplayInterface {
	
}
